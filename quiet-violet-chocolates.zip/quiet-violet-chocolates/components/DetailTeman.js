import React from 'react';
import { View, Text, Button, StyleSheet, Image } from 'react-native';

function DetailTeman({ teman, onKembaliKlik }) {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Detail Informasi</Text>
      <Image source={teman.foto} style={styles.foto} />
      <View style={styles.infoContainer}>
        <Text style={styles.label}><strong>Nama:</strong> {teman.nama}</Text>
        <Text style={styles.label}><strong>Deskripsi:</strong> {teman.deskripsi}</Text>
        <Text style={styles.label}><strong>Alamat:</strong> {teman.alamat}</Text>
      </View>
      <Button title="Home" onPress={onKembaliKlik} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f0f0f0',
  },
  header: {
    fontSize: 28,
    marginBottom: 20,
    fontWeight: 'bold',
  },
  foto: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 20,
  },
  infoContainer: {
    alignItems: 'flex-start',
    width: '100%',
    paddingHorizontal: 20,
  },
  label: {
    fontSize: 18,
    marginBottom: 10,
    color: '#666',
  },
});

export default DetailTeman;
