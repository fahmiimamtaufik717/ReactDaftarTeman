import React from 'react';
import { View, Text, Button, StyleSheet, Image } from 'react-native';

function DaftarTeman({ teman, onTemanKlik }) {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Aplikasi Daftar Teman</Text>
      {teman.map((t) => (
        <View key={t.id} style={styles.temanContainer}>
          <Image source={t.foto} style={styles.foto} />
          <View style={styles.temanInfo}>
            <Text style={styles.nama}>{t.nama}</Text>
            <Button title="Lihat Detail" onPress={() => onTemanKlik(t)} />
          </View>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    fontSize: 24,
    marginBottom: 20,
  },
  temanContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  foto: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  temanInfo: {
    flex: 1,
  },
  nama: {
    fontSize: 18,
  },
});

export default DaftarTeman;
