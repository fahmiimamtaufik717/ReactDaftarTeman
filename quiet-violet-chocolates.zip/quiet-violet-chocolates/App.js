import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import DaftarTeman from './components/DaftarTeman';
import DetailTeman from './components/DetailTeman';

// Data teman
const teman = [
  { id: 1, nama: 'Ariya Andika', deskripsi: 'Suka melukis dan aktivitas luar ruangan.', alamat: 'Jl. R. Syamsudin, S.H. No. 50, Cikole, Kec. Cikole, Kota Sukabumi, Jawa Barat 43113', foto: require('./assets/abuy.jpg') },
  { id: 2, nama: 'Muhammad Aditya', deskripsi: 'Suka bermain gitar dan membaca buku.',alamat: 'Jl. R. Syamsudin, S.H. No. 50, Cikole, Kec. Cikole, Kota Sukabumi, Jawa Barat 43113', foto: require('./assets/adit.jpg') },
  { id: 3, nama: 'Meitia', deskripsi: 'Penggemar bersepeda dan teknologi.',alamat: 'Jl. R. Syamsudin, S.H. No. 50, Cikole, Kec. Cikole, Kota Sukabumi, Jawa Barat 43113', foto: require('./assets/meitia.jpg') },
  { id: 4, nama: 'Fahmi', deskripsi: 'Suka melukis dan aktivitas luar ruangan.', alamat: 'Jl. R. Syamsudin, S.H. No. 50, Cikole, Kec. Cikole, Kota Sukabumi, Jawa Barat 43113', foto: require('./assets/fahmi.jpg') },
  { id: 5, nama: 'Rani Febriani', deskripsi: 'Suka bermain gitar dan membaca buku.',alamat: 'Jl. R. Syamsudin, S.H. No. 50, Cikole, Kec. Cikole, Kota Sukabumi, Jawa Barat 43113', foto: require('./assets/rani.jpg') },
  { id: 6, nama: 'Eneng Rahayu', deskripsi: 'Penggemar bersepeda dan teknologi.',alamat: 'Jl. R. Syamsudin, S.H. No. 50, Cikole, Kec. Cikole, Kota Sukabumi, Jawa Barat 43113', foto: require('./assets/eneng.jpg') },
  // Tambahkan data teman lainnya di sini
];

function App() {
  const [temanTerpilih, setTemanTerpilih] = useState(null);

  const handleKlikTeman = (teman) => {
    setTemanTerpilih(teman);
  };

  const handleKlikKembali = () => {
    setTemanTerpilih(null);
  };

  return (
    <View style={styles.container}>
      {temanTerpilih ? (
        <DetailTeman teman={temanTerpilih} onKembaliKlik={handleKlikKembali} />
      ) : (
        <DaftarTeman teman={teman} onTemanKlik={handleKlikTeman} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default App;
